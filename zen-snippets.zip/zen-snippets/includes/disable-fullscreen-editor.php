<?php

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

if (is_admin()) {

	add_action(
		'enqueue_block_editor_assets',
		function () {
			$script = "jQuery( window ).load(function() { const isFullscreenMode = wp.data.select( 'core/edit-post' ).isFeatureActive( 'fullscreenMode' ); if ( isFullscreenMode ) { wp.data.dispatch( 'core/edit-post' ).toggleFeature( 'fullscreenMode' ); } });";
			wp_add_inline_script( 'wp-blocks', $script );
		}
	);

};